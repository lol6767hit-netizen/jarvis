package com.example.jarvis

import android.app.*
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis is on")
            .setContentText("Tap the bubble to talk. Tap Stop to shut down.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (bubble == null) addBubble()
        return START_NOT_STICKY
    }

    private fun addBubble() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = (64 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "AI"; gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF3B82F6.toInt()) }
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }

        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            var moved = false; var closed = false
            val slop = ViewConfiguration.get(this@OverlayService).scaledTouchSlop
            val longPress = Runnable {
                if (!moved) { closed = true; say("Jarvis closed"); stopSelf() }
            }
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                        main.postDelayed(longPress, 900)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (abs(dx) > slop || abs(dy) > slop) { moved = true; main.removeCallbacks(longPress) }
                        if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(v, lp) }
                    }
                    MotionEvent.ACTION_UP -> {
                        main.removeCallbacks(longPress)
                        if (!moved && !closed) listen()
                    }
                    MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longPress)
                }
                return true
            }
        })
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun setLabel(s: String) { bubble?.text = s }
    private fun say(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("No speech recognizer on this phone"); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { setLabel("🎤") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { setLabel("…") }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) { setLabel("AI"); say("Didn't catch that") }
                override fun onResults(r: Bundle?) {
                    val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text == null) { setLabel("AI"); return }
                    say("Heard: $text")
                    handle(text)
                }
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        }
    }

    private fun handle(spoken: String) {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val key = prefs.getString("key", "") ?: ""
        val tree = prefs.getString("tree", null)?.let { Uri.parse(it) }
        thread {
            try {
                val cmd = ClaudeClient.parse(key, spoken)
                if (cmd.action != "send_file") { main.post { setLabel("AI"); say("I can only send files for now") }; return@thread }
                if (tree == null) { main.post { setLabel("AI"); say("Choose a folder in the app first") }; return@thread }
                val doc = FileFinder.find(this, tree, cmd.file)
                if (doc == null) { main.post { setLabel("AI"); say("No matching file found") }; return@thread }
                val dir = File(cacheDir, "share").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
                val out = File(dir, doc.name ?: "file")
                contentResolver.openInputStream(doc.uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", out)
                main.post { setLabel("AI"); launchShare(uri, doc.type ?: "*/*", cmd) }
            } catch (e: Exception) {
                main.post { setLabel("AI"); say("Error: ${e.message}") }
            }
        }
    }

    private fun packageFor(app: String): String? {
        val pkg = when (app.lowercase()) {
            "whatsapp" -> "com.whatsapp"
            "telegram" -> "org.telegram.messenger"
            "gmail", "email" -> "com.google.android.gm"
            "signal" -> "org.thoughtcrime.securesms"
            "sms", "messages" -> "com.google.android.apps.messaging"
            else -> return null
        }
        return if (packageManager.getLaunchIntentForPackage(pkg) != null) pkg else null
    }

    private fun launchShare(uri: Uri, mime: String, cmd: ClaudeClient.Cmd) {
        val pkg = packageFor(cmd.app)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            if (pkg != null) setPackage(pkg)
        }
        if (cmd.contact.isNotBlank() && pkg != null && AutoSendService.running) AutoSend.arm(cmd.contact)
        startActivity(
            if (pkg != null) send
            else Intent.createChooser(send, "Send").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}

object FileFinder {
    fun find(ctx: Context, tree: Uri, hint: String): DocumentFile? {
        val files = DocumentFile.fromTreeUri(ctx, tree)?.listFiles()?.filter { it.isFile } ?: return null
        val sorted = files.sortedByDescending { it.lastModified() }
        if (hint.isBlank() || hint.equals("latest", true)) return sorted.firstOrNull()
        return sorted.firstOrNull { it.name?.contains(hint, true) == true }
    }
}
