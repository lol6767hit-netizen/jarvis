package com.example.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {
    const val MODEL = "claude-sonnet-5-5" // change if you want a different model

    data class Cmd(val action: String, val file: String, val contact: String, val app: String)

    private const val SYSTEM = """You turn a spoken phone command into JSON. Reply with ONLY a JSON object, no other text:
{"action":"send_file"|"unknown","file":"latest" or a keyword from the file name,"contact":"person's name","app":"whatsapp"|"telegram"|"gmail"|"signal"|"sms"|""}
"the file Claude made", "this file", "the last download" all mean file="latest"."""

    fun parse(key: String, spoken: String): Cmd {
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 200)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", spoken)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) error("API error $code")
        val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        val j = JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
        return Cmd(
            j.optString("action", "unknown"),
            j.optString("file", "latest"),
            j.optString("contact", ""),
            j.optString("app", "")
        )
    }
}
