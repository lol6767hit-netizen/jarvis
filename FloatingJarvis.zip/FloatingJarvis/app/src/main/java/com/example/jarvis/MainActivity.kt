package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var keyBox: EditText
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        keyBox = EditText(this).apply {
            hint = "Anthropic API key"
            setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(keyBox)
        fun btn(label: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = label; setOnClickListener { f() } })
        }
        btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow microphone + notifications") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("3. Choose folder for Claude's files (make a subfolder, e.g. Download/Claude)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 7)
        }
        btn("4. (Optional) Turn on auto-send in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("START JARVIS") { start() }
        info = TextView(this).apply { setPadding(0, 32, 0, 0) }
        col.addView(info)
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        info.text = "Folder: " + (prefs.getString("tree", null) ?: "not chosen") +
            "\nAuto-send: " + if (AutoSendService.running) "ON" else "off (you tap Send)"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == 7 && res == RESULT_OK && uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("tree", uri.toString()).apply()
        }
    }

    private fun start() {
        prefs.edit().putString("key", keyBox.text.toString().trim()).apply()
        when {
            keyBox.text.isBlank() -> toast("Enter your API key")
            !Settings.canDrawOverlays(this) -> toast("Do step 1")
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED -> toast("Do step 2")
            prefs.getString("tree", null) == null -> toast("Do step 3")
            else -> {
                startForegroundService(Intent(this, OverlayService::class.java))
                finish()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
