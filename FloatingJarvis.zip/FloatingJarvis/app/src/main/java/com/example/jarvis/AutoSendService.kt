package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Armed for 25 seconds after a voice command. Does nothing otherwise. */
object AutoSend {
    @Volatile var contact: String? = null
    @Volatile var deadline = 0L
    @Volatile var typed = false
    @Volatile var picked = false
    fun arm(c: String) { contact = c; deadline = System.currentTimeMillis() + 25_000; typed = false; picked = false }
    fun active() = contact != null && System.currentTimeMillis() < deadline
}

class AutoSendService : AccessibilityService() {
    companion object { @Volatile var running = false }

    override fun onServiceConnected() { running = true }
    override fun onUnbind(i: Intent?): Boolean { running = false; return super.onUnbind(i) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!AutoSend.active()) return
        val root = rootInActiveWindow ?: return
        val name = AutoSend.contact ?: return

        if (!AutoSend.picked) {
            val hits = root.findAccessibilityNodeInfosByText(name)
                .filter { it.className?.toString() != "android.widget.EditText" }
            for (h in hits) if (clickUp(h)) { AutoSend.picked = true; return }
            if (!AutoSend.typed) {
                val edit = findEditable(root)
                if (edit != null) {
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, name)
                    }
                    edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    AutoSend.typed = true
                }
            }
            return
        }
        for (s in root.findAccessibilityNodeInfosByText("Send")) {
            if (clickUp(s)) { AutoSend.contact = null; return }
        }
    }

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
        }
        return false
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }
}
