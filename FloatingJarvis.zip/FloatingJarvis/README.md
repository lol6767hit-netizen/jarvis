# Floating Jarvis

Tap app -> floating bubble. Tap bubble -> speak. Long-press bubble (or notification "Stop") -> everything shuts down.

## Build
1. Install Android Studio. File > Open > this folder. Let Gradle sync.
2. Enable Developer options + USB debugging on your phone, plug in, press Run.
3. Open the app: paste your Anthropic API key, do steps 1-3, tap START JARVIS.

## Use
Tap the bubble, say: "Send the latest file to Rahul on WhatsApp".
Make a folder like Download/Claude and save Claude's files there (Android blocks picking the Downloads root).

## Auto-send (optional)
Step 4 > turn on "Floating Jarvis". If Android says "restricted setting": phone Settings > Apps > Floating Jarvis > ⋮ > Allow restricted settings.
It only works inside WhatsApp / Telegram / Gmail / Signal / Google Messages, and only for 25 s after a command.
It reads screen text, so it is fragile: app updates can break it. Without it, you pick the contact/tap Send yourself.

Change the model in ClaudeClient.kt (MODEL).
